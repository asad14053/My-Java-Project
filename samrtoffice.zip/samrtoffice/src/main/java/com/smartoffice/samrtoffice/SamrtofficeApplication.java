package com.smartoffice.samrtoffice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamrtofficeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamrtofficeApplication.class, args);
	}
}
